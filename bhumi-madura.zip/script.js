const dict={bedeh:'ada',engghi:'iya',bhunten:'tidak'};
function translateWord(){
 const w=document.getElementById('wordInput').value.toLowerCase();
 document.getElementById('result').innerText=dict[w]||'Tidak ditemukan';
}
